<?php
session_start();

$page = $_GET['page'] ?? '';
if ($page === '') {
    $page = 'annonces';
}
?>
<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>LeBonCoin</title>
    <link rel="stylesheet" href="./assets/style.css" />
    <link rel="stylesheet" href="./assets/header.style.css" />
    <link rel="stylesheet" href="./assets/footer.style.css" />

    <?php
    if ($page === 'annonces') {
        echo '<link rel="stylesheet" href="./assets/annonces.style.css" />';
    } elseif ($page === 'register') {
        echo '<link rel="stylesheet" href="./assets/inscription.style.css" />';
    } elseif ($page === 'login') {
        echo '<link rel="stylesheet" href="./assets/connexion.style.css" />';
    } elseif ($page === 'annonce_create') {
        echo '<link rel="stylesheet" href="./assets/annonce-create.style.css" />';
    } elseif ($page === 'annonce_edit') {
        echo '<link rel="stylesheet" href="./assets/annonce-create.style.css" />';
    } elseif ($page === 'annonce_detail') {
        echo '<link rel="stylesheet" href="./assets/annonce-detail.style.css" />';
    } elseif ($page === 'favoris') {
        echo '<link rel="stylesheet" href="./assets/favoris.style.css" />';
    } elseif ($page === 'messages') {
        echo '<link rel="stylesheet" href="./assets/messages.style.css" />';
    } elseif ($page === 'profil') {
        echo '<link rel="stylesheet" href="./assets/profil.style.css" />';
    }
    elseif ($page === 'apropos') {
    echo '<link rel="stylesheet" href="./assets/apropos.style.css" />';
}
    ?>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
</head>

<body data-logged-in="<?= !empty($_SESSION['user_id']) ? '1' : '0' ?>">

<?php
require_once __DIR__ . '/config/database.php';

$userResult    = null;
$annonceResult = null;
$profilResult  = null;
$flash         = null;

// ── ACTIONS POST ─────────────────────────────────────────────────────────────

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // ── Contrôleur utilisateur ────────────────────────────────────────────────
    if ($page === 'register' || $page === 'login') {
        require_once __DIR__ . '/controllers/user.controller.php';
        $userController = new UserController();

        if ($page === 'register') {
            $userResult = $userController->inscription();
        } elseif ($page === 'login') {
            $userController->connexion();
        }
    }

    // ── Actions profil ────────────────────────────────────────────────────────
    if ($page === 'profil' && isset($_POST['action'])) {
        require_once __DIR__ . '/controllers/user.controller.php';
        $userController = new UserController();

        if ($_POST['action'] === 'modifier_email') {
            $profilResult = $userController->modifierEmail();
        } elseif ($_POST['action'] === 'modifier_mdp') {
            $profilResult = $userController->modifierMotDePasse();
        } elseif ($_POST['action'] === 'supprimer_compte') {
            $userController->supprimerCompte();
        }
    }

    // ── Contrôleur annonce ────────────────────────────────────────────────────
    if (isset($_POST['action']) && str_starts_with($_POST['action'], 'annonce_')) {
        require_once __DIR__ . '/controllers/annonce.controller.php';
        $annonceController = new AnnonceController();

        if ($_POST['action'] === 'annonce_create') {
            $annonceResult = $annonceController->creer();
            if (!empty($annonceResult['success'])) {
                header('Location: index.php?page=annonces');
                exit;
            }
        } elseif ($_POST['action'] === 'annonce_edit' && isset($_POST['annonce_id'])) {
            $annonceResult = $annonceController->modifier((int) $_POST['annonce_id']);
            if (!empty($annonceResult['success'])) {
                header('Location: index.php?page=annonces');
                exit;
            }
        } elseif ($_POST['action'] === 'annonce_delete' && isset($_POST['annonce_id'])) {
            $annonceResult = $annonceController->supprimer((int) $_POST['annonce_id']);
            if (!empty($annonceResult['success'])) {
                header('Location: index.php?page=annonces');
                exit;
            }
        }
    }

    // ── Contrôleur favori ─────────────────────────────────────────────────────
    if (isset($_POST['action']) && str_starts_with($_POST['action'], 'favori_')) {
        require_once __DIR__ . '/controllers/favori.controller.php';
        $favoriController = new FavoriController();

        if ($_POST['action'] === 'favori_toggle' && isset($_POST['annonce_id'])) {
            $favoriController->toggle((int) $_POST['annonce_id']);
            header('Location: ' . ($_SERVER['HTTP_REFERER'] ?? 'index.php'));
            exit;
        }
    }

    // ── Contrôleur message ────────────────────────────────────────────────────
    if (isset($_POST['action']) && str_starts_with($_POST['action'], 'message_')) {
        require_once __DIR__ . '/controllers/message.controller.php';
        $messageController = new MessageController();

        if ($_POST['action'] === 'message_send' && isset($_POST['annonce_id'])) {
            $messageController->envoyer((int) $_POST['annonce_id']);
        }
    }
}

// ── ACTION GET logout ─────────────────────────────────────────────────────────
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    require_once __DIR__ . '/controllers/user.controller.php';
    $userController = new UserController();
    $userController->deconnexion();
}

// ── Flash message ─────────────────────────────────────────────────────────────
$flash = $_SESSION['flash'] ?? null;
if (isset($_SESSION['flash'])) {
    unset($_SESSION['flash']);
}

// ── Header ────────────────────────────────────────────────────────────────────
require_once __DIR__ . '/views/components/header.php';

// ── Routing vues ─────────────────────────────────────────────────────────────
if ($page === 'annonces') {
    require_once __DIR__ . '/controllers/annonce.controller.php';
    require_once __DIR__ . '/controllers/favori.controller.php';
    $annonceController = new AnnonceController();
    $favoriController  = new FavoriController();
    $filtres = [
    'recherche' => $_GET['recherche'] ?? '',
    'categorie' => $_GET['categorie'] ?? '',
    'prix_min'  => $_GET['prix_min']  ?? '',
    'prix_max'  => $_GET['prix_max']  ?? '',
    'tri'       => $_GET['tri']       ?? '',
];
    $annonces   = $annonceController->getAll($filtres);
    $populaires = $annonceController->getPopulaires(5);
    require_once __DIR__ . '/views/annonces.view.php';

} elseif ($page === 'annonce_detail') {
    require_once __DIR__ . '/controllers/annonce.controller.php';
    require_once __DIR__ . '/controllers/favori.controller.php';
    $annonceController = new AnnonceController();
    $favoriController  = new FavoriController();
    $annonce = $annonceController->getById((int) ($_GET['id'] ?? 0));
    require_once __DIR__ . '/views/annonce-detail.view.php';

} elseif ($page === 'annonce_create') {
    if (empty($_SESSION['user_id'])) {
        header('Location: index.php?page=login');
        exit;
    }
    require_once __DIR__ . '/controllers/annonce.controller.php';
    require_once __DIR__ . '/views/annonce-create.view.php';

} elseif ($page === 'annonce_edit') {
    if (empty($_SESSION['user_id'])) {
        header('Location: index.php?page=login');
        exit;
    }
    require_once __DIR__ . '/controllers/annonce.controller.php';
    $annonceController = new AnnonceController();
    $annonce = $annonceController->getById((int) ($_GET['id'] ?? 0));
    require_once __DIR__ . '/views/annonce-edit.view.php';

} elseif ($page === 'register') {
    require_once __DIR__ . '/views/inscription.view.php';

} elseif ($page === 'login') {
    require_once __DIR__ . '/views/connexion.view.php';

} elseif ($page === 'favoris') {
    if (empty($_SESSION['user_id'])) {
        header('Location: index.php?page=login');
        exit;
    }
    require_once __DIR__ . '/controllers/favori.controller.php';
    $favoriController = new FavoriController();
    $favoris = $favoriController->getFavoris();
    require_once __DIR__ . '/views/favoris.view.php';

} elseif ($page === 'messages') {
    if (empty($_SESSION['user_id'])) {
        header('Location: index.php?page=login');
        exit;
    }
    require_once __DIR__ . '/controllers/message.controller.php';
    $messageController = new MessageController();
    $conversations = $messageController->getConversations();
    require_once __DIR__ . '/views/messages.view.php';

} elseif ($page === 'profil') {
    if (empty($_SESSION['user_id'])) {
        header('Location: index.php?page=login');
        exit;
    }
    require_once __DIR__ . '/controllers/user.controller.php';
    $userController = new UserController();
    $profilData  = $userController->getProfil((int) $_SESSION['user_id']);
    $mesAnnonces = $userController->getMesAnnonces((int) $_SESSION['user_id']);
    require_once __DIR__ . '/views/profil.view.php';
}
 elseif ($page === 'apropos') {
    require_once __DIR__ . '/views/apropos.view.php';
}

// ── Footer ────────────────────────────────────────────────────────────────────
require_once __DIR__ . '/views/components/footer.php';
?>

<script src="./assets/js/script.js"></script>

</body>
</html>