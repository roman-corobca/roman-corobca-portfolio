# Projet collectif leboncoin-bts-sio

Application pédagogique de petites annonces, inspirée du fonctionnement d’une plateforme d’annonces. Projet de groupe ; cette copie ne présente pas Roman COROBCA comme auteur unique.

Source : https://github.com/patriciablbn/leboncoin-bts-sio
Référence consultée : e4a6829ec47a91fccc812797a5cb56320950b5f7 (branche main).
Contributeurs affichés : roman-corobca, patriciablbn, linamansour4106. Les contributions individuelles restent à préciser.

## Copie préparée pour téléchargement

Les données SQL d’exemple, les images téléversées et la configuration de connexion d’origine sont exclues. La structure des tables et le code applicatif sont conservés. config/database.php est remplacé par une configuration via variables d’environnement. Aucune modification n’est apportée au dépôt d’origine.

## Exécution locale

Utiliser PHP 8 ou plus récent avec PDO MySQL et mbstring, ainsi qu’un serveur MySQL ou MariaDB. Créer une base vide et importer db/leboncoin.sql uniquement. Définir DB_HOST, DB_PORT, DB_NAME, DB_USER et DB_PASSWORD dans l’environnement du serveur. Rendre uploads/ accessible en écriture. Servir index.php depuis le serveur PHP. Activer output_buffering=4096 pour la démonstration ; déplacer les traitements avant le HTML est préférable pour les redirections.

## Limites constatées lors de la lecture

Le JavaScript référence api/annonces.php, absent de la copie de la branche main examinée. Le filtre dynamique produit une erreur dans l’essai local ; le chargement direct de page avec filtres GET fonctionne pour la catégorie testée. Une démonstration avec PHP 8.3.28 et MariaDB 11.4.9, données fictives et configuration adaptée, a vérifié l’affichage, l’inscription, la connexion, la création sans photo, la modification de prix, l’ajout d’un favori et l’envoi d’un message. Les essais ne sont pas exhaustifs et ne constituent pas un audit. Consulter le guide illustré pour les limites. Ce projet PHP ne s’exécute pas sur GitHub Pages : le portfolio fournit ses sources et sa documentation.

Roman COROBCA a confirmé l’accord du groupe pour cette copie publique et sa documentation. Aucune licence générale de redistribution n’est ajoutée à cette copie.
