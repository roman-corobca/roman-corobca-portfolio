# Projet collectif leboncoin-bts-sio

Application pédagogique de petites annonces, inspirée du fonctionnement d’une plateforme d’annonces. Projet de groupe ; cette copie ne présente pas Roman COROBCA comme auteur unique.

Source : https://github.com/patriciablbn/leboncoin-bts-sio
Référence consultée : e4a6829ec47a91fccc812797a5cb56320950b5f7 (branche main).
Contributeurs affichés : roman-corobca, patriciablbn, linamansour4106. Les contributions individuelles restent à préciser.

## Copie préparée pour téléchargement

Les données SQL d’exemple, les images téléversées et la configuration de connexion d’origine sont exclues. La structure des tables et le code applicatif sont conservés. config/database.php est remplacé par une configuration via variables d’environnement. Aucune modification n’est apportée au dépôt d’origine.

## Exécution locale

Utiliser PHP 8 ou plus récent avec PDO MySQL, ainsi qu’un serveur MySQL ou MariaDB. Créer une base vide et importer un seul des fichiers de structure SQL adapté au projet. Définir DB_HOST, DB_PORT, DB_NAME, DB_USER et DB_PASSWORD dans l’environnement du serveur. Rendre uploads/ accessible en écriture. Servir index.php depuis le serveur PHP.

## Limites constatées lors de la lecture

Le JavaScript référence api/annonces.php, absent de la copie de la branche main examinée. La recherche dynamique demande donc une vérification ou l’ajout de cette API. Les fonctions et les résultats n’ont pas été testés en exécution. Vérifier notamment le schéma sélectionné, les redirections HTTP, les contrôles d’accès, les protections CSRF et la validation des fichiers avant un usage réel. Ce projet PHP ne s’exécute pas sur GitHub Pages : le portfolio fournit ses sources et sa documentation.

La mise à disposition publique de ce projet de groupe reste soumise à l’accord de partage du groupe. Aucune licence de redistribution n’est ajoutée à cette copie.
