// ══════════════════════════════════════════════
//  Toggle mot de passe (œil)
// ══════════════════════════════════════════════
const eyeOpen = `
<svg class="eye-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
    <circle cx="12" cy="12" r="3"/>
</svg>`;

const eyeClosed = `
<svg class="eye-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
    <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94"/>
    <path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19"/>
    <line x1="1" y1="1" x2="23" y2="23"/>
</svg>`;

document.querySelectorAll('.toggle-password').forEach(btn => {
    btn.addEventListener('click', () => {
        const input = document.getElementById(btn.dataset.target);
        if (input.type === 'password') {
            input.type = 'text';
            btn.innerHTML = eyeClosed;
        } else {
            input.type = 'password';
            btn.innerHTML = eyeOpen;
        }
    });
});

// ══════════════════════════════════════════════
//  Onglets profil
// ══════════════════════════════════════════════
document.querySelectorAll('.profil-tab').forEach(tab => {
    tab.addEventListener('click', () => {
        document.querySelectorAll('.profil-tab, .profil-panel').forEach(el => el.classList.remove('active'));
        tab.classList.add('active');
        document.getElementById('tab-' + tab.dataset.tab).classList.add('active');
    });
});

// ══════════════════════════════════════════════
//  AJAX — Recherche / Filtre / Tri en temps réel
// ══════════════════════════════════════════════
(function () {
    const form       = document.querySelector('.annonces-filters');
    const grid       = document.querySelector('.annonces-grid');
    const countEl    = document.querySelector('.annonces-count');
    const emptyEl    = document.querySelector('.annonces-empty');
    const isLoggedIn = document.body.dataset.loggedIn === '1';

    // Si on n'est pas sur la page annonces, on sort
    if (!form || !grid) return;

    // Masque le bouton Filtrer (tout est automatique), garde Réinitialiser
    const submitBtn = form.querySelector('button[type="submit"]');
    const resetLink = form.querySelector('a.btn--secondary');
    if (submitBtn) submitBtn.style.display = 'none';
    if (resetLink) {
        resetLink.addEventListener('click', (e) => {
            e.preventDefault();
            form.querySelectorAll('input[type="text"], input[type="number"]').forEach(i => i.value = '');
            form.querySelectorAll('select').forEach(s => s.selectedIndex = 0);
            fetchAnnonces();
        });
    }

    let debounceTimer = null;

    // Ecoute tous les champs du formulaire
    form.querySelectorAll('input, select').forEach(el => {
        const event = el.tagName === 'SELECT' ? 'change' : 'input';
        el.addEventListener(event, () => {
            clearTimeout(debounceTimer);
            debounceTimer = setTimeout(fetchAnnonces, el.tagName === 'SELECT' ? 100 : 350);
        });
    });

    // Empeche la soumission classique
    form.addEventListener('submit', (e) => {
        e.preventDefault();
        fetchAnnonces();
    });

    // Construit l'URL de l'API avec les filtres
    function buildUrl() {
        const params = new URLSearchParams();
        const recherche = form.querySelector('[name="recherche"]')?.value.trim() || '';
        const categorie = form.querySelector('[name="categorie"]')?.value || '';
        const prixMin   = form.querySelector('[name="prix_min"]')?.value || '';
        const prixMax   = form.querySelector('[name="prix_max"]')?.value || '';
        const tri       = form.querySelector('[name="tri"]')?.value || 'created_at_desc';

        if (recherche) params.set('recherche', recherche);
        if (categorie) params.set('categorie', categorie);
        if (prixMin)   params.set('prix_min', prixMin);
        if (prixMax)   params.set('prix_max', prixMax);
        params.set('tri', tri);

        const base = window.location.pathname.replace(/\/index.php$/, '').replace(/\/$/, '');
        return `${base}/api/annonces.php?${params.toString()}`;
    }

    // Loader pendant le fetch
    function showLoader() {
        grid.innerHTML = `
            <div style="grid-column:1/-1; text-align:center; padding:60px 0; color:#9ca3af;">
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#f56b2a" stroke-width="2"
                     style="animation:spin .7s linear infinite; display:inline-block">
                    <circle cx="12" cy="12" r="10" stroke="#f3f4f6" stroke-width="3"/>
                    <path d="M12 2a10 10 0 0 1 10 10" stroke="#f56b2a" stroke-width="3" stroke-linecap="round"/>
                </svg>
                <p style="margin-top:12px; font-size:.88rem">Chargement...</p>
            </div>`;
        if (emptyEl) emptyEl.style.display = 'none';
    }

    // Echappe le HTML (protection XSS)
    function escHtml(str) {
        return String(str)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }

    // Genere le HTML d'une carte populaire
    function renderPopulaire(a) {
        const photoHtml = a.photo
            ? `<img class="populaire-card__img" src="./uploads/${escHtml(a.photo)}" alt="${escHtml(a.titre)}">`
            : `<div class="populaire-card__no-img">Pas de photo</div>`;

        return `
            <a href="index.php?page=annonce_detail&id=${a.id}" class="populaire-card">
                ${photoHtml}
                <div class="populaire-card__body">
                    <p class="populaire-card__categorie">${escHtml(a.categorie)}</p>
                    <p class="populaire-card__title">${escHtml(a.titre)}</p>
                    <p class="populaire-card__price">${a.prix} €</p>
                    <span class="populaire-card__vues">
                        <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                        ${a.nb_vues} vue${a.nb_vues > 1 ? 's' : ''}
                    </span>
                </div>
            </a>`;
    }

    // Genere le HTML d'une carte annonce
    function renderCard(a) {
        const photoHtml = a.photo
            ? `<img class="annonce-card__img" src="./uploads/${escHtml(a.photo)}" alt="${escHtml(a.titre)}">`
            : `<div class="annonce-card__no-img">Pas de photo</div>`;

        const favoriHtml = isLoggedIn ? `
            <form method="POST" action="index.php" class="favori-form">
                <input type="hidden" name="action" value="favori_toggle">
                <input type="hidden" name="annonce_id" value="${a.id}">
                <button type="submit" class="favori-btn ${a.is_favori ? 'favori-btn--active' : ''}" title="Ajouter aux favoris">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/>
                    </svg>
                </button>
            </form>` : '';

        return `
            <div class="annonce-card-wrapper">
                <a href="index.php?page=annonce_detail&id=${a.id}" class="annonce-card">
                    ${photoHtml}
                    <div class="annonce-card__body">
                        <p class="annonce-card__categorie">${escHtml(a.categorie)}</p>
                        <p class="annonce-card__title">${escHtml(a.titre)}</p>
                        <p class="annonce-card__price">${a.prix} €</p>
                        <div class="annonce-card__meta">
                            <span>${escHtml(a.vendeur_email)}</span>
                            <span>${a.created_at}</span>
                        </div>
                    </div>
                </a>
                ${favoriHtml}
            </div>`;
    }

    // Fetch principal vers l'API
    async function fetchAnnonces() {
        showLoader();
        try {
            const res  = await fetch(buildUrl());
            if (!res.ok) throw new Error('Erreur reseau');
            const json = await res.json();

            // Mise a jour du compteur
            if (countEl) {
                const n = json.count;
                countEl.textContent = `${n} annonce${n > 1 ? 's' : ''} trouvee${n > 1 ? 's' : ''}`;
                countEl.style.display = n > 0 ? 'block' : 'none';
            }

            if (json.count === 0) {
                grid.innerHTML = '';
                if (emptyEl) {
                    emptyEl.textContent = 'Aucune annonce ne correspond à votre recherche.';
                    emptyEl.style.display = 'block';
                }
            } else {
                if (emptyEl) emptyEl.style.display = 'none';
                grid.innerHTML = json.data.map(renderCard).join('');
            }

            // Mise a jour des populaires
            const popGrid = document.querySelector('.populaires-grid');
            const popSection = document.getElementById('populaires-section');
            if (popGrid && json.populaires) {
                if (json.populaires.length === 0) {
                    if (popSection) popSection.style.display = 'none';
                } else {
                    if (popSection) popSection.style.display = 'block';
                    popGrid.innerHTML = json.populaires.map(renderPopulaire).join('');
                }
            }
        } catch (err) {
            grid.innerHTML = `<p class="annonces-empty" style="grid-column:1/-1">Une erreur est survenue. Veuillez reessayer.</p>`;
            console.error('Erreur AJAX :', err);
        }
    }

    // Animation spinner
    const style = document.createElement('style');
    style.textContent = `@keyframes spin { to { transform: rotate(360deg); } }`;
    document.head.appendChild(style);

})();