<main class="apropos-main">

    <div class="apropos-hero">
        <h1>À propos du projet</h1>
        <p>Un clone de LeBonCoin réalisé dans le cadre d'un projet scolaire</p>
    </div>

    <div class="apropos-container">

        <!-- ── Pourquoi ce projet ── -->
        <section class="apropos-section">
            <div class="apropos-section__icon">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#f56b2a" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="12" cy="12" r="10"/><path d="M12 8v4l3 3"/>
                </svg>
            </div>
            <div>
                <h2>Pourquoi ce projet ?</h2>
                <p>
                    Ce projet a été réalisé dans le cadre d'un projet scolaire. L'objectif était de concevoir
                    une application web complète inspirée de LeBonCoin, en partant de zéro et en appliquant
                    les bonnes pratiques du développement web moderne.
                </p>
            </div>
        </section>

        <!-- ── Ce qu'on a appris ── -->
        <section class="apropos-section">
            <div class="apropos-section__icon">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#f56b2a" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/>
                </svg>
            </div>
            <div>
                <h2>Ce qu'on a appris</h2>
                <p>Ce projet nous a permis de découvrir et maîtriser plusieurs concepts clés :</p>
                <div class="apropos-skills">
                    <div class="apropos-skill">
                        <div class="apropos-skill__icon">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#f56b2a" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/>
                            </svg>
                        </div>
                        <div>
                            <strong>Architecture MVC</strong>
                            <p>Séparation du code en Modèles, Vues et Contrôleurs pour un projet maintenable et structuré.</p>
                        </div>
                    </div>
                    <div class="apropos-skill">
                        <div class="apropos-skill__icon">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#f56b2a" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/>
                            </svg>
                        </div>
                        <div>
                            <strong>Barre de recherche & filtres</strong>
                            <p>Recherche par mot-clé, filtrage par catégorie, prix min/max et tri des résultats.</p>
                        </div>
                    </div>
                    <div class="apropos-skill">
                        <div class="apropos-skill__icon">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#f56b2a" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/>
                            </svg>
                        </div>
                        <div>
                            <strong>Upload d'images</strong>
                            <p>Gestion de l'upload de photos avec validation du format et de la taille côté serveur.</p>
                        </div>
                    </div>
                    <div class="apropos-skill">
                        <div class="apropos-skill__icon">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#f56b2a" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>
                            </svg>
                        </div>
                        <div>
                            <strong>Authentification sécurisée</strong>
                            <p>Système d'inscription et de connexion avec hashage des mots de passe et gestion des sessions.</p>
                        </div>
                    </div>
                    <div class="apropos-skill">
                        <div class="apropos-skill__icon">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#f56b2a" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
                            </svg>
                        </div>
                        <div>
                            <strong>Messagerie</strong>
                            <p>Système de messagerie entre acheteurs et vendeurs lié aux annonces.</p>
                        </div>
                    </div>
                    <div class="apropos-skill">
                        <div class="apropos-skill__icon">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#f56b2a" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
                            </svg>
                        </div>
                        <div>
                            <strong>Système de favoris</strong>
                            <p>Ajout et retrait d'annonces en favoris avec persistance en base de données.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- ── Stack technique ── -->
        <section class="apropos-section">
            <div class="apropos-section__icon">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#f56b2a" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="12" cy="12" r="3"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14M4.93 4.93a10 10 0 0 0 0 14.14"/>
                </svg>
            </div>
            <div>
                <h2>Stack technique</h2>
                <div class="apropos-stack">
                    <span class="apropos-tag">PHP</span>
                    <span class="apropos-tag">MySQL</span>
                    <span class="apropos-tag">HTML5</span>
                    <span class="apropos-tag">CSS3</span>
                    <span class="apropos-tag">JavaScript</span>
                    <span class="apropos-tag">Architecture MVC</span>
                    <span class="apropos-tag">PDO</span>
                    <span class="apropos-tag">XAMPP</span>
                </div>
            </div>
        </section>

        <!-- ── Équipe ── -->
        <section class="apropos-section">
            <div class="apropos-section__icon">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#f56b2a" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>
                </svg>
            </div>
            <div>
                <h2>L'équipe</h2>
                <p>Ce projet a été réalisé en groupe. Un grand merci à tous les membres pour leur implication.</p>
                <div class="apropos-team">
                    <div class="apropos-member apropos-member--lead">
                        <div class="apropos-member__avatar">K</div>
                        <div>
                            <strong>Kidd</strong>
                            <span>Lead développeur</span>
                        </div>
                    </div>
                    <div class="apropos-member">
                        <div class="apropos-member__avatar">S</div>
                        <div>
                            <strong>Sandrine Santos</strong>
                            <span>Chef de projet</span>
                        </div>
                    </div>
                    <div class="apropos-member">
                        <div class="apropos-member__avatar">S</div>
                        <div>
                            <strong>Sidouane Chendjou</strong>
                            <span>Frontend</span>
                        </div>
                    </div>
                    <div class="apropos-member">
                        <div class="apropos-member__avatar">D</div>
                        <div>
                            <strong>Djalil Diabagate</strong>
                            <span>Intégrateur & Testeur</span>
                        </div>
                    </div>
                </div>
            </div>
        </section>

    </div>

</main>