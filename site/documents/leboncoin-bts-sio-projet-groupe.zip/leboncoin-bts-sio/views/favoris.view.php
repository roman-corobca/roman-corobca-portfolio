<main class="favoris-main">

    <div class="favoris-header">
    <div>
        <h1>Mes favoris</h1>
        <p class="favoris-count">
            <?= !empty($favoris) ? count($favoris) . ' annonce' . (count($favoris) > 1 ? 's' : '') . ' en favori' : '' ?>
        </p>
    </div>
    <a href="index.php?page=annonces" class="btn btn--secondary">Voir toutes les annonces</a>
</div>

    <?php if (!empty($flash)): ?>
        <p class="message message--<?= $flash['type'] ?>">
            <?= htmlspecialchars($flash['message']) ?>
        </p>
    <?php endif; ?>

    <?php if (empty($favoris)): ?>
        <div class="favoris-empty">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#ddd" stroke-width="1.5">
                <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/>
            </svg>
            <p>Vous n'avez pas encore de favoris.</p>
            <span>Cliquez sur le ❤ sur une annonce pour l'ajouter à vos favoris.</span>
            <a href="index.php?page=annonces" class="btn btn--primary">Parcourir les annonces</a>
        </div>
    <?php else: ?>
        <div class="favoris-grid">
            <?php foreach ($favoris as $annonce): ?>
                <div class="favoris-card">

                    <a href="index.php?page=annonce_detail&id=<?= $annonce['id'] ?>" class="favoris-card__img-link">
                        <?php if (!empty($annonce['photo'])): ?>
                            <img src="./uploads/<?= htmlspecialchars($annonce['photo']) ?>"
                                 alt="<?= htmlspecialchars($annonce['titre']) ?>"
                                 class="favoris-card__img">
                        <?php else: ?>
                            <div class="favoris-card__no-img">Pas de photo</div>
                        <?php endif; ?>
                    </a>

                    <div class="favoris-card__body">
                        <div class="favoris-card__top">
                            <span class="favoris-card__categorie"><?= htmlspecialchars($annonce['categorie']) ?></span>
                            <form method="POST" action="index.php">
                                <input type="hidden" name="action" value="favori_toggle">
                                <input type="hidden" name="annonce_id" value="<?= $annonce['id'] ?>">
                                <button type="submit" class="favoris-card__remove" title="Retirer des favoris">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                                        <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/>
                                    </svg>
                                </button>
                            </form>
                        </div>

                        <a href="index.php?page=annonce_detail&id=<?= $annonce['id'] ?>" class="favoris-card__title">
                            <?= htmlspecialchars($annonce['titre']) ?>
                        </a>

                        <p class="favoris-card__price"><?= number_format($annonce['prix'], 2, ',', ' ') ?> €</p>

                        <div class="favoris-card__footer">
                            <span class="favoris-card__vendeur"><?= htmlspecialchars($annonce['vendeur_email']) ?></span>
                            <span class="favoris-card__date"><?= date('d/m/Y', strtotime($annonce['created_at'])) ?></span>
                        </div>

                        <a href="index.php?page=annonce_detail&id=<?= $annonce['id'] ?>" class="favoris-card__btn">
                            Voir l'annonce
                        </a>
                    </div>

                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

</main>