<main class="annonces-main">

    <div class="annonces-top">
        <h1>Les annonces</h1>
        <?php if (!empty($_SESSION['user_id'])): ?>
            <a href="index.php?page=annonce_create" class="btn btn--primary">+ Déposer une annonce</a>
        <?php endif; ?>
    </div>

    <!-- ── FILTRES ── -->
    <form method="GET" action="index.php" class="annonces-filters">
        <input type="hidden" name="page" value="annonces">

        <input type="text" name="recherche" placeholder="Rechercher..."
               value="<?= htmlspecialchars($_GET['recherche'] ?? '') ?>">

        <select name="categorie">
            <option value="">Toutes les catégories</option>
            <?php foreach (AnnonceController::CATEGORIES as $cat): ?>
                <option value="<?= htmlspecialchars($cat) ?>"
                    <?= ($_GET['categorie'] ?? '') === $cat ? 'selected' : '' ?>>
                    <?= htmlspecialchars($cat) ?>
                </option>
            <?php endforeach; ?>
        </select>

        <input type="number" name="prix_min" placeholder="Prix min (€)" min="0"
               value="<?= htmlspecialchars($_GET['prix_min'] ?? '') ?>">

        <input type="number" name="prix_max" placeholder="Prix max (€)" min="0"
               value="<?= htmlspecialchars($_GET['prix_max'] ?? '') ?>">

        <select name="tri">
            <option value="created_at_desc" <?= ($_GET['tri'] ?? '') === 'created_at_desc' ? 'selected' : '' ?>>Plus récent</option>
            <option value="created_at_asc"  <?= ($_GET['tri'] ?? '') === 'created_at_asc'  ? 'selected' : '' ?>>Plus ancien</option>
            <option value="prix_asc"        <?= ($_GET['tri'] ?? '') === 'prix_asc'        ? 'selected' : '' ?>>Prix croissant</option>
            <option value="prix_desc"       <?= ($_GET['tri'] ?? '') === 'prix_desc'       ? 'selected' : '' ?>>Prix décroissant</option>
        </select>

        <button type="submit" class="btn btn--primary">Filtrer</button>
        <a href="index.php?page=annonces" class="btn btn--secondary">Réinitialiser</a>
    </form>


    <!-- ── ANNONCES LES PLUS CONSULTÉES ── -->
    <?php if (!empty($populaires)): ?>
    <div class="populaires-section" id="populaires-section">
        <h2 class="populaires-titre">🔥 Les plus consultées</h2>
        <div class="populaires-grid">
            <?php foreach ($populaires as $pop): ?>
                <a href="index.php?page=annonce_detail&id=<?= $pop['id'] ?>" class="populaire-card">
                    <?php if (!empty($pop['photo'])): ?>
                        <img class="populaire-card__img"
                             src="./uploads/<?= htmlspecialchars($pop['photo']) ?>"
                             alt="<?= htmlspecialchars($pop['titre']) ?>">
                    <?php else: ?>
                        <div class="populaire-card__no-img">Pas de photo</div>
                    <?php endif; ?>
                    <div class="populaire-card__body">
                        <p class="populaire-card__categorie"><?= htmlspecialchars($pop['categorie']) ?></p>
                        <p class="populaire-card__title"><?= htmlspecialchars($pop['titre']) ?></p>
                        <p class="populaire-card__price"><?= number_format($pop['prix'], 2, ',', ' ') ?> €</p>
                        <span class="populaire-card__vues">
                            <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                            <?= $pop['nb_vues'] ?> vue<?= $pop['nb_vues'] > 1 ? 's' : '' ?>
                        </span>
                    </div>
                </a>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>

        <!-- ── LISTE ── -->
    <?php if (empty($annonces)): ?>
        <p class="annonces-empty">Aucune annonce ne correspond à votre recherche.</p>
    <?php else: ?>
        <p class="annonces-count"><?= count($annonces) ?> annonce<?= count($annonces) > 1 ? 's' : '' ?> trouvée<?= count($annonces) > 1 ? 's' : '' ?></p>
        <div class="annonces-grid">
            <?php foreach ($annonces as $annonce): ?>
                <div class="annonce-card-wrapper">
                    <a href="index.php?page=annonce_detail&id=<?= $annonce['id'] ?>" class="annonce-card">
                        <?php if (!empty($annonce['photo'])): ?>
                            <img class="annonce-card__img"
                                 src="./uploads/<?= htmlspecialchars($annonce['photo']) ?>"
                                 alt="<?= htmlspecialchars($annonce['titre']) ?>">
                        <?php else: ?>
                            <div class="annonce-card__no-img">Pas de photo</div>
                        <?php endif; ?>
                        <div class="annonce-card__body">
                            <p class="annonce-card__categorie"><?= htmlspecialchars($annonce['categorie']) ?></p>
                            <p class="annonce-card__title"><?= htmlspecialchars($annonce['titre']) ?></p>
                            <p class="annonce-card__price"><?= number_format($annonce['prix'], 2, ',', ' ') ?> €</p>
                            <div class="annonce-card__meta">
                                <span><?= htmlspecialchars($annonce['vendeur_email']) ?></span>
                                <span><?= date('d/m/Y', strtotime($annonce['created_at'])) ?></span>
                            </div>
                        </div>
                    </a>

                    <?php if (isset($_SESSION['user_id'])): ?>
                        <form method="POST" action="index.php" class="favori-form">
                            <input type="hidden" name="action" value="favori_toggle">
                            <input type="hidden" name="annonce_id" value="<?= $annonce['id'] ?>">
                            <button type="submit" class="favori-btn <?= $favoriController->isFavori($annonce['id']) ? 'favori-btn--active' : '' ?>" title="Ajouter aux favoris">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                                    <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/>
                                </svg>
                            </button>
                        </form>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

</main>