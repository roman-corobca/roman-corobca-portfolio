<main class="auth-main">
    <div class="auth-card">
        <h1>Créer un compte</h1>

        <?php if (!empty($userResult)): ?>
            <p class="message <?= str_contains($userResult, 'réussie') ? 'message--success' : 'message--error' ?>">
                <?= htmlspecialchars($userResult) ?>
            </p>
        <?php endif; ?>

        <form method="POST" action="index.php?page=register">
            <label for="email">Adresse email</label>
            <input type="email" id="email" name="email"
                   value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"
                   required autocomplete="email">

            <label for="password">Mot de passe</label>
            <div class="input-password-wrapper">
                <input type="password" id="password" name="password" required autocomplete="new-password">
                <button type="button" class="toggle-password" data-target="password" aria-label="Afficher le mot de passe">
                    <svg class="eye-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                        <circle cx="12" cy="12" r="3"/>
                    </svg>
                </button>
            </div>
            <p class="input-hint">Minimum 10 caractères</p>

            <label for="confirm">Confirmer le mot de passe</label>
            <div class="input-password-wrapper">
                <input type="password" id="confirm" name="confirm" required autocomplete="new-password">
                <button type="button" class="toggle-password" data-target="confirm" aria-label="Afficher le mot de passe">
                    <svg class="eye-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                        <circle cx="12" cy="12" r="3"/>
                    </svg>
                </button>
            </div>

            <button type="submit" name="action" value="inscription">S'inscrire</button>
        </form>

        <p class="auth-link">
            Déjà un compte ? <a href="index.php?page=login">Se connecter</a>
        </p>
    </div>
</main>