<main class="annonce-detail-main">

    <?php if (!$annonce): ?>
        <p class="message message--error">Annonce introuvable.</p>
    <?php else: ?>

        <div class="annonce-detail-container">

            <!-- ── IMAGE ── -->
            <div class="annonce-detail-img-wrapper">
                <?php if (!empty($annonce['photo'])): ?>
                    <img src="./uploads/<?= htmlspecialchars($annonce['photo']) ?>"
                         alt="<?= htmlspecialchars($annonce['titre']) ?>">
                <?php else: ?>
                    <div class="annonce-detail-no-img">Pas de photo</div>
                <?php endif; ?>
            </div>

            <!-- ── INFOS ── -->
            <div class="annonce-detail-infos">
                <span class="annonce-detail-categorie"><?= htmlspecialchars($annonce['categorie']) ?></span>
                <h1><?= htmlspecialchars($annonce['titre']) ?></h1>
                <p class="annonce-detail-prix"><?= number_format($annonce['prix'], 2, ',', ' ') ?> €</p>
                
                <?php if (isset($_SESSION['user_id']) && $_SESSION['user_id'] != $annonce['user_id']): ?>
    <form method="POST" action="index.php" class="favori-form">
        <input type="hidden" name="action" value="favori_toggle">
        <input type="hidden" name="annonce_id" value="<?= $annonce['id'] ?>">
        <button type="submit" class="favori-btn-detail <?= $favoriController->isFavori($annonce['id']) ? 'favori-btn--active' : '' ?>">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="18" height="18">
                <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/>
            </svg>
            <?= $favoriController->isFavori($annonce['id']) ? 'Retirer des favoris' : 'Ajouter aux favoris' ?>
        </button>
    </form>
<?php endif; ?>

                <div class="annonce-detail-meta">
                    <p>Vendeur : <strong><?= htmlspecialchars($annonce['vendeur_email']) ?></strong></p>
                    <p>Publié le : <?= date('d/m/Y', strtotime($annonce['created_at'])) ?></p>
                    <p>Vues : <?= $annonce['nb_vues'] ?></p>
                </div>

                <div class="annonce-detail-description">
                    <h2>Description</h2>
                    <p><?= nl2br(htmlspecialchars($annonce['description'])) ?></p>
                </div>

                <!-- ── ACTIONS PROPRIÉTAIRE ── -->
                <?php if (isset($_SESSION['user_id']) && $_SESSION['user_id'] == $annonce['user_id']): ?>
                    <div class="annonce-detail-owner-actions">
                        <a href="index.php?page=annonce_edit&id=<?= $annonce['id'] ?>" class="btn btn--secondary">Modifier</a>
                        <form method="POST" action="index.php"
                              onsubmit="return confirm('Supprimer cette annonce ?')">
                            <input type="hidden" name="action" value="annonce_delete">
                            <input type="hidden" name="annonce_id" value="<?= $annonce['id'] ?>">
                            <button type="submit" class="btn btn--danger">Supprimer</button>
                        </form>
                    </div>
                <?php endif; ?>

                <!-- ── CONTACTER ── -->
                <?php if (isset($_SESSION['user_id']) && $_SESSION['user_id'] != $annonce['user_id']): ?>
                    <div class="annonce-detail-contact">
                        <h2>Contacter le vendeur</h2>
                        <form method="POST" action="index.php">
                            <input type="hidden" name="action" value="message_send">
                            <input type="hidden" name="annonce_id" value="<?= $annonce['id'] ?>">
                            <textarea name="contenu" rows="4"
                                      placeholder="Bonjour, je suis intéressé par votre annonce..." required></textarea>
                                      <input type="hidden" name="destinataire_id" value="<?= $annonce['user_id'] ?>">
                            <button type="submit" class="btn btn--primary">Envoyer le message</button>
                        </form>
                    </div>
                <?php elseif (!isset($_SESSION['user_id'])): ?>
                    <p class="annonce-detail-login-hint">
                        <a href="index.php?page=login">Connectez-vous</a> pour contacter le vendeur.
                    </p>
                <?php endif; ?>

            </div>
        </div>

    <?php endif; ?>

</main>