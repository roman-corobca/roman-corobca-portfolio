<main class="profil-container">

    <?php if (!empty($profilResult)): ?>
        <p class="message <?= str_contains($profilResult, 'succès') ? 'message--success' : 'message--error' ?>">
            <?= htmlspecialchars($profilResult) ?>
        </p>
    <?php endif; ?>

    <?php if (!empty($flash)): ?>
        <p class="message message--<?= $flash['type'] ?>">
            <?= htmlspecialchars($flash['message']) ?>
        </p>
    <?php endif; ?>

    <!-- ── EN-TÊTE PROFIL ── -->
    <div class="profil-header">
        <div class="profil-avatar">
            <?= strtoupper(mb_substr($profilData['email'], 0, 1)) ?>
        </div>
        <div class="profil-header-info">
            <h1><?= htmlspecialchars($profilData['email']) ?></h1>
            <p>Membre depuis le <?= date('d/m/Y', strtotime($profilData['created_at'])) ?></p>
        </div>
    </div>

    <!-- ── ONGLETS ── -->
    <div class="profil-tabs">
        <button class="profil-tab active" data-tab="infos">Mes informations</button>
        <button class="profil-tab" data-tab="securite">Sécurité</button>
        <button class="profil-tab" data-tab="annonces">
            Mes annonces
            <span class="profil-tab-count"><?= count($mesAnnonces) ?></span>
        </button>
        <button class="profil-tab profil-tab--danger" data-tab="danger">Supprimer le compte</button>
    </div>

    <div class="profil-content">

        <!-- ── ONGLET : INFOS ── -->
        <div class="profil-panel active" id="tab-infos">
            <h2>Modifier mon email</h2>
            <form method="POST" action="index.php?page=profil" class="profil-form">
                <input type="hidden" name="action" value="modifier_email">
                <div class="profil-form-group">
                    <label for="email">Nouvel email</label>
                    <input type="email" id="email" name="email"
                           value="<?= htmlspecialchars($profilData['email']) ?>" required>
                </div>
                <div class="profil-form-group">
                    <label for="password">Confirmer avec votre mot de passe</label>
                    <div class="input-password-wrapper">
                        <input type="password" id="password" name="password" required>
                        <button type="button" class="toggle-password" data-target="password" aria-label="Afficher le mot de passe">
                            <svg class="eye-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                                <circle cx="12" cy="12" r="3"/>
                            </svg>
                        </button>
                    </div>
                </div>
                <button type="submit" class="profil-btn-save">Mettre à jour</button>
            </form>
        </div>

        <!-- ── ONGLET : SÉCURITÉ ── -->
        <div class="profil-panel" id="tab-securite">
            <h2>Modifier mon mot de passe</h2>
            <form method="POST" action="index.php?page=profil" class="profil-form">
                <input type="hidden" name="action" value="modifier_mdp">
                <div class="profil-form-group">
                    <label for="ancien_password">Ancien mot de passe</label>
                    <div class="input-password-wrapper">
                        <input type="password" id="ancien_password" name="ancien_password" required>
                        <button type="button" class="toggle-password" data-target="ancien_password" aria-label="Afficher le mot de passe">
                            <svg class="eye-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                                <circle cx="12" cy="12" r="3"/>
                            </svg>
                        </button>
                    </div>
                </div>
                <div class="profil-form-group">
                    <label for="nouveau_password">Nouveau mot de passe</label>
                    <div class="input-password-wrapper">
                        <input type="password" id="nouveau_password" name="nouveau_password" required>
                        <button type="button" class="toggle-password" data-target="nouveau_password" aria-label="Afficher le mot de passe">
                            <svg class="eye-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                                <circle cx="12" cy="12" r="3"/>
                            </svg>
                        </button>
                    </div>
                    <p class="input-hint">Minimum 10 caractères</p>
                </div>
                <div class="profil-form-group">
                    <label for="confirm_password">Confirmer le nouveau mot de passe</label>
                    <div class="input-password-wrapper">
                        <input type="password" id="confirm_password" name="confirm_password" required>
                        <button type="button" class="toggle-password" data-target="confirm_password" aria-label="Afficher le mot de passe">
                            <svg class="eye-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                                <circle cx="12" cy="12" r="3"/>
                            </svg>
                        </button>
                    </div>
                </div>
                <button type="submit" class="profil-btn-save">Modifier</button>
            </form>
        </div>

        <!-- ── ONGLET : MES ANNONCES ── -->
        <div class="profil-panel" id="tab-annonces">
            <h2>Mes annonces</h2>
            <?php if (empty($mesAnnonces)): ?>
                <p class="profil-empty">Vous n'avez pas encore publié d'annonce.</p>
            <?php else: ?>
                <div class="profil-annonces">
                    <?php foreach ($mesAnnonces as $annonce): ?>
                        <div class="profil-annonce-card">
                            <?php if (!empty($annonce['photo'])): ?>
                                <img src="./uploads/<?= htmlspecialchars($annonce['photo']) ?>" alt="photo">
                            <?php else: ?>
                                <div class="profil-annonce-card__no-img">Pas de photo</div>
                            <?php endif; ?>
                            <div class="profil-annonce-card__body">
                                <p class="profil-annonce-card__titre"><?= htmlspecialchars($annonce['titre']) ?></p>
                                <p class="profil-annonce-card__prix"><?= number_format($annonce['prix'], 2, ',', ' ') ?> €</p>
                                <p class="profil-annonce-card__date"><?= date('d/m/Y', strtotime($annonce['created_at'])) ?></p>
                                <div class="profil-annonce-card__actions">
                                    <a href="index.php?page=annonce_edit&id=<?= $annonce['id'] ?>" class="btn btn--secondary">Modifier</a>
                                    <form method="POST" action="index.php"
                                          onsubmit="return confirm('Supprimer cette annonce ?')">
                                        <input type="hidden" name="action" value="annonce_delete">
                                        <input type="hidden" name="annonce_id" value="<?= $annonce['id'] ?>">
                                        <button type="submit" class="btn btn--danger">Supprimer</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- ── ONGLET : SUPPRIMER ── -->
        <div class="profil-panel" id="tab-danger">
            <h2>Supprimer mon compte</h2>
            <p class="profil-danger-text">
                Cette action est <strong>irréversible</strong>. Toutes vos annonces, favoris et messages seront supprimés définitivement.
            </p>
            <form method="POST" action="index.php?page=profil" class="profil-form profil-form--danger"
                  onsubmit="return confirm('Êtes-vous sûr de vouloir supprimer votre compte ?')">
                <input type="hidden" name="action" value="supprimer_compte">
                <div class="profil-form-group">
                    <label for="password_confirm">Confirmer avec votre mot de passe</label>
                    <div class="input-password-wrapper">
                        <input type="password" id="password_confirm" name="password_confirm" required>
                        <button type="button" class="toggle-password" data-target="password_confirm" aria-label="Afficher le mot de passe">
                            <svg class="eye-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                                <circle cx="12" cy="12" r="3"/>
                            </svg>
                        </button>
                    </div>
                </div>
                <button type="submit" class="profil-btn-danger">Supprimer mon compte</button>
            </form>
        </div>

    </div>

</main>

