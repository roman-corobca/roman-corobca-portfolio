<main class="auth-main">
    <div class="auth-card">
        <h1>Se connecter</h1>

        <?php if (!empty($flash)): ?>
            <p class="message message--<?= $flash['type'] ?>">
                <?= htmlspecialchars($flash['message']) ?>
            </p>
        <?php endif; ?>

        <form method="POST" action="index.php?page=login">
            <label for="email">Adresse email</label>
            <input type="email" id="email" name="email"
                   value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"
                   required autocomplete="email">

            <label for="password">Mot de passe</label>
            <div class="input-password-wrapper">
                <input type="password" id="password" name="password" required autocomplete="current-password">
              <button type="button" class="toggle-password" data-target="password" aria-label="Afficher le mot de passe">
                    <svg class="eye-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                        <circle cx="12" cy="12" r="3"/>
                    </svg>
                </button>
            </div>

            <button type="submit" name="action" value="connexion">Se connecter</button>
        </form>

        <p class="auth-link">
            Pas encore de compte ? <a href="index.php?page=register">S'inscrire</a>
        </p>
    </div>
</main>