<main class="annonce-create-main">

    <div class="annonce-create-container">
        <h1>Déposer une annonce</h1>

        <?php if (!empty($annonceResult['error'])): ?>
            <p class="message message--error"><?= htmlspecialchars($annonceResult['error']) ?></p>
        <?php endif; ?>

        <form method="POST" action="index.php?page=annonce_create"
              enctype="multipart/form-data" class="annonce-form">
            <input type="hidden" name="action" value="annonce_create">

            <div class="annonce-form-group">
                <label for="titre">Titre de l'annonce *</label>
                <input type="text" id="titre" name="titre"
                       value="<?= htmlspecialchars($_POST['titre'] ?? '') ?>"
                       placeholder="Ex : iPhone 14 Pro Max 256Go" required>
            </div>

            <div class="annonce-form-row">
                <div class="annonce-form-group">
                    <label for="prix">Prix (€) *</label>
                    <input type="number" id="prix" name="prix" min="0" step="0.01"
                           value="<?= htmlspecialchars($_POST['prix'] ?? '') ?>"
                           placeholder="0.00" required>
                </div>
                <div class="annonce-form-group">
                    <label for="categorie">Catégorie *</label>
                    <select id="categorie" name="categorie" required>
                        <option value="">-- Choisir --</option>
                        <?php foreach (AnnonceController::CATEGORIES as $cat): ?>
                            <option value="<?= htmlspecialchars($cat) ?>"
                                <?= ($_POST['categorie'] ?? '') === $cat ? 'selected' : '' ?>>
                                <?= htmlspecialchars($cat) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <div class="annonce-form-group">
                <label for="description">Description *</label>
                <textarea id="description" name="description" rows="6"
                          placeholder="Décrivez votre article en détail..." required><?= htmlspecialchars($_POST['description'] ?? '') ?></textarea>
            </div>

            <div class="annonce-form-group">
                <label for="photo">Photo</label>
                <div class="annonce-upload">
                    <input type="file" id="photo" name="photo"
                           accept="image/jpeg,image/png,image/webp">
                    <p class="input-hint">Formats acceptés : jpg, png, webp — 5 Mo max</p>
                </div>
                <div class="annonce-preview" id="photoPreview" style="display:none;">
                    <img id="previewImg" src="" alt="Aperçu">
                    <button type="button" id="removePhoto">✕ Supprimer</button>
                </div>
            </div>

            <div class="annonce-form-actions">
                <a href="index.php" class="btn btn--secondary">Annuler</a>
                <button type="submit" class="btn btn--primary">Publier l'annonce</button>
            </div>
        </form>
    </div>

</main>

<script>
// Aperçu de la photo avant upload
const input   = document.getElementById('photo');
const preview = document.getElementById('photoPreview');
const img     = document.getElementById('previewImg');
const remove  = document.getElementById('removePhoto');

input.addEventListener('change', () => {
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = e => {
            img.src = e.target.result;
            preview.style.display = 'flex';
        };
        reader.readAsDataURL(input.files[0]);
    }
});

remove.addEventListener('click', () => {
    input.value = '';
    img.src = '';
    preview.style.display = 'none';
});
</script>