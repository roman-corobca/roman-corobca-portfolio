<?php
$currentPage = $_GET['page'] ?? 'annonces';
$nbNonLus = 0;
if (isset($_SESSION['user_id'])) {
    require_once __DIR__ . '/../../controllers/message.controller.php';
    $messageController = new MessageController();
    $nbNonLus = $messageController->countUnread();
}
?>
<nav class="navbar">
    <a class="navbar__logo" href="index.php">leboncoin</a>

    <div class="navbar__links">
        <a href="index.php" class="<?= $currentPage === 'annonces' ? 'active' : '' ?>">Annonces</a>

        <?php if (isset($_SESSION['user_id'])): ?>
            <a href="index.php?page=favoris" class="<?= $currentPage === 'favoris' ? 'active' : '' ?>">Favoris</a>
            <a href="index.php?page=messages" class="<?= $currentPage === 'messages' ? 'active' : '' ?>">
                Messages
                <?php if ($nbNonLus > 0): ?>
                    <span class="navbar__badge"><?= $nbNonLus ?></span>
                <?php endif; ?>
            </a>
            <a href="index.php?page=profil" class="<?= $currentPage === 'profil' ? 'active' : '' ?>">Mon compte</a>
            <a href="index.php?action=logout" class="navbar__logout">Se déconnecter</a>
        <?php else: ?>
            <a href="index.php?page=login" class="<?= $currentPage === 'login' ? 'active' : '' ?>">Se connecter</a>
            <a href="index.php?page=register" class="navbar__btn">Créer un compte</a>
        <?php endif; ?>
    </div>
</nav>