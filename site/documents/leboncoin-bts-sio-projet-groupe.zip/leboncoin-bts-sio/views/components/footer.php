<footer class="footer">
    <p>&copy; <?= date('Y') ?> leboncoin — Tous droits réservés</p>
    <a href="index.php?page=apropos" style="color:#f56b2a; font-weight:600;">À propos du projet</a>
</footer>