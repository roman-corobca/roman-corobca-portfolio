<main class="annonce-create-main">

    <div class="annonce-create-container">
        <h1>Modifier l'annonce</h1>

        <?php if (!empty($annonceResult['error'])): ?>
            <p class="message message--error"><?= htmlspecialchars($annonceResult['error']) ?></p>
        <?php endif; ?>

        <?php if (!$annonce): ?>
            <p class="message message--error">Annonce introuvable.</p>
        <?php else: ?>

        <form method="POST" action="index.php?page=annonce_edit&id=<?= $annonce['id'] ?>"
              enctype="multipart/form-data" class="annonce-form">
            <input type="hidden" name="action" value="annonce_edit">
            <input type="hidden" name="annonce_id" value="<?= $annonce['id'] ?>">

            <div class="annonce-form-group">
                <label for="titre">Titre de l'annonce *</label>
                <input type="text" id="titre" name="titre"
                       value="<?= htmlspecialchars($_POST['titre'] ?? $annonce['titre']) ?>" required>
            </div>

            <div class="annonce-form-row">
                <div class="annonce-form-group">
                    <label for="prix">Prix (€) *</label>
                    <input type="number" id="prix" name="prix" min="0" step="0.01"
                           value="<?= htmlspecialchars($_POST['prix'] ?? $annonce['prix']) ?>" required>
                </div>
                <div class="annonce-form-group">
                    <label for="categorie">Catégorie *</label>
                    <select id="categorie" name="categorie" required>
                        <option value="">-- Choisir --</option>
                        <?php foreach (AnnonceController::CATEGORIES as $cat): ?>
                            <option value="<?= htmlspecialchars($cat) ?>"
                                <?= (($_POST['categorie'] ?? $annonce['categorie']) === $cat) ? 'selected' : '' ?>>
                                <?= htmlspecialchars($cat) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <div class="annonce-form-group">
                <label for="description">Description *</label>
                <textarea id="description" name="description" rows="6" required><?= htmlspecialchars($_POST['description'] ?? $annonce['description']) ?></textarea>
            </div>

            <div class="annonce-form-group">
                <label>Photo actuelle</label>
                <?php if (!empty($annonce['photo'])): ?>
                    <img src="./uploads/<?= htmlspecialchars($annonce['photo']) ?>"
                         alt="photo actuelle" class="annonce-edit-current-img">
                <?php else: ?>
                    <p class="input-hint">Aucune photo</p>
                <?php endif; ?>
                <label for="photo" style="margin-top:12px;">Changer la photo</label>
                <input type="file" id="photo" name="photo"
                       accept="image/jpeg,image/png,image/webp">
                <p class="input-hint">Laisser vide pour conserver la photo actuelle</p>
            </div>

            <div class="annonce-form-actions">
                <a href="index.php?page=annonce_detail&id=<?= $annonce['id'] ?>" class="btn btn--secondary">Annuler</a>
                <button type="submit" class="btn btn--primary">Enregistrer les modifications</button>
            </div>
        </form>

        <?php endif; ?>
    </div>

</main>