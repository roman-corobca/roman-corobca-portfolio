<main class="messages-main">

    <div class="messages-header">
        <h1>Mes messages</h1>
        <?php if (!empty($conversations)): ?>
            <p class="messages-count">
                <?php
                $vusCount = [];
                $total = 0;
                foreach ($conversations as $msg) {
                    $interlocuteur = $msg['expediteur_id'] == $_SESSION['user_id'] ? $msg['destinataire_id'] : $msg['expediteur_id'];
                    $cle = $msg['annonce_id'] . '_' . $interlocuteur;
                    if (!in_array($cle, $vusCount)) { $vusCount[] = $cle; $total++; }
                }
                echo $total . ' conversation' . ($total > 1 ? 's' : '');
                ?>
            </p>
        <?php endif; ?>
    </div>

    <?php if (!empty($flash)): ?>
        <p class="message message--<?= $flash['type'] ?>">
            <?= htmlspecialchars($flash['message']) ?>
        </p>
    <?php endif; ?>

    <?php if (empty($conversations)): ?>
        <div class="messages-empty">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#ddd" stroke-width="1.5" width="80" height="80">
                <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
            </svg>
            <p>Vous n'avez pas encore de messages.</p>
            <span>Contactez un vendeur depuis une annonce pour démarrer une conversation.</span>
            <a href="index.php" class="btn btn--primary">Voir les annonces</a>
        </div>
    <?php else: ?>

        <div class="messages-layout <?= isset($_GET['annonce_id']) ? 'messages-layout--open' : '' ?>">

            <!-- ── Liste conversations ── -->
            <div class="messages-list">
                <?php
                $vus = [];
                foreach ($conversations as $msg):
                    $interlocuteur = $msg['expediteur_id'] == $_SESSION['user_id']
                        ? $msg['destinataire_id']
                        : $msg['expediteur_id'];
                    $cle = $msg['annonce_id'] . '_' . $interlocuteur;
                    if (in_array($cle, $vus)) continue;
                    $vus[] = $cle;

                    $interlocuteurEmail = $msg['expediteur_id'] == $_SESSION['user_id']
                        ? $msg['destinataire_email']
                        : $msg['expediteur_email'];

                    $isActive = isset($_GET['annonce_id']) && $_GET['annonce_id'] == $msg['annonce_id'] && isset($_GET['avec']) && $_GET['avec'] == $interlocuteur;
                    $isUnread = !$msg['lu'] && $msg['destinataire_id'] == $_SESSION['user_id'];
                ?>
                    <a href="index.php?page=messages&annonce_id=<?= $msg['annonce_id'] ?>&avec=<?= $interlocuteur ?>"
                       class="messages-item <?= $isUnread ? 'messages-item--unread' : '' ?> <?= $isActive ? 'messages-item--active' : '' ?>">

                        <?php if (!empty($msg['annonce_photo'])): ?>
                            <img src="./uploads/<?= htmlspecialchars($msg['annonce_photo']) ?>"
                                 alt="photo" class="messages-item__img">
                        <?php else: ?>
                            <div class="messages-item__no-img">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" width="22" height="22">
                                    <rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/>
                                </svg>
                            </div>
                        <?php endif; ?>

                        <div class="messages-item__body">
                            <p class="messages-item__annonce"><?= htmlspecialchars($msg['annonce_titre']) ?></p>
                            <p class="messages-item__interlocuteur"><?= htmlspecialchars($interlocuteurEmail) ?></p>
                            <p class="messages-item__extrait"><?= htmlspecialchars(mb_substr($msg['contenu'], 0, 60)) ?>...</p>
                        </div>

                        <div class="messages-item__meta">
                            <span><?= date('d/m/Y', strtotime($msg['created_at'])) ?></span>
                            <?php if ($isUnread): ?>
                                <span class="messages-item__badge">Nouveau</span>
                            <?php endif; ?>
                        </div>
                    </a>
                <?php endforeach; ?>
            </div>

            <!-- ── Conversation ouverte ── -->
            <?php if (isset($_GET['annonce_id'], $_GET['avec'])): ?>
                <?php
                $messagesConv = $messageController->getMessages(
                    (int) $_GET['annonce_id'],
                    (int) $_GET['avec']
                );
                ?>
                <div class="messages-conv">
                    <div class="messages-conv__header">
                        <h2>Conversation</h2>
                        <a href="index.php?page=messages" class="messages-conv__close">✕</a>
                    </div>

                    <div class="messages-conv__liste" id="messagesListe">
                        <?php if (empty($messagesConv)): ?>
                            <p class="messages-conv__empty">Aucun message dans cette conversation.</p>
                        <?php else: ?>
                            <?php foreach ($messagesConv as $m): ?>
                                <div class="messages-conv__msg <?= $m['expediteur_id'] == $_SESSION['user_id'] ? 'messages-conv__msg--moi' : 'messages-conv__msg--eux' ?>">
                                    <p><?= nl2br(htmlspecialchars($m['contenu'])) ?></p>
                                    <span><?= date('d/m/Y H:i', strtotime($m['created_at'])) ?></span>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>

                    <form method="POST" action="index.php" class="messages-conv__reply">
                        <input type="hidden" name="action" value="message_send">
                        <input type="hidden" name="annonce_id" value="<?= (int) $_GET['annonce_id'] ?>">
                        <input type="hidden" name="destinataire_id" value="<?= (int) $_GET['avec'] ?>">
                        <textarea name="contenu" rows="2" placeholder="Écrivez votre message..." required></textarea>
                        <button type="submit" class="btn btn--primary">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="16" height="16">
                                <path d="M2 21l21-9L2 3v7l15 2-15 2v7z"/>
                            </svg>
                        </button>
                    </form>
                </div>
            <?php else: ?>
                <div class="messages-conv-placeholder">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#e5e7eb" stroke-width="1.5" width="60" height="60">
                        <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
                    </svg>
                    <p>Sélectionnez une conversation</p>
                </div>
            <?php endif; ?>

        </div>

    <?php endif; ?>

</main>

<script>
// Auto-scroll vers le bas de la conversation
const liste = document.getElementById('messagesListe');
if (liste) liste.scrollTop = liste.scrollHeight;
</script>