<?php
require_once __DIR__ . '/../models/annonce.model.php';

class AnnonceController
{
    private AnnonceModel $model;

    const CATEGORIES = [
        'Véhicules',
        'Immobilier',
        'Informatique',
        'Mode',
        'Sports & Loisirs',
        'Maison & Jardin',
        'Autres',
    ];

    public function __construct()
    {
        $this->model = new AnnonceModel();
    }

    /** Retourne les annonces les plus consultées */
    public function getPopulaires(int $limite = 5): array
    {
        return $this->model->findPopulaires($limite);
    }

        /** Retourne toutes les annonces avec filtres */
    public function getAll(array $filtres = []): array
    {
        return $this->model->findAll($filtres);
    }

    /** Retourne une annonce par ID et incrémente les vues */
    public function getById(int $id): array|false
    {
        $annonce = $this->model->findById($id);
        if ($annonce) {
            $this->model->incrementVues($id);
        }
        return $annonce;
    }

    /** Crée une annonce */
    public function creer(): array
    {
        if (empty($_SESSION['user_id'])) {
            return ['error' => 'Vous devez être connecté.'];
        }

        $titre       = trim($_POST['titre']       ?? '');
        $description = trim($_POST['description'] ?? '');
        $prix        = $_POST['prix']             ?? '';
        $categorie   = $_POST['categorie']        ?? '';

        if (empty($titre) || empty($description) || $prix === '' || empty($categorie)) {
            return ['error' => 'Tous les champs obligatoires doivent être remplis.'];
        }
        if (!is_numeric($prix) || (float)$prix < 0) {
            return ['error' => 'Le prix doit être un nombre positif.'];
        }
        if (!in_array($categorie, self::CATEGORIES)) {
            return ['error' => 'Catégorie invalide.'];
        }

        $photo = $this->uploadPhoto();
        if (isset($photo['error'])) {
            return $photo;
        }

        $this->model->create(
            (int) $_SESSION['user_id'],
            $titre,
            $description,
            (float) $prix,
            $categorie,
            $photo
        );

        return ['success' => 'Annonce publiée avec succès.'];
    }

    /** Modifie une annonce */
    public function modifier(int $id): array
    {
        if (empty($_SESSION['user_id'])) {
            return ['error' => 'Vous devez être connecté.'];
        }

        $annonce = $this->model->findById($id);
        if (!$annonce || $annonce['user_id'] !== (int) $_SESSION['user_id']) {
            return ['error' => 'Annonce introuvable ou accès refusé.'];
        }

        $titre       = trim($_POST['titre']       ?? '');
        $description = trim($_POST['description'] ?? '');
        $prix        = $_POST['prix']             ?? '';
        $categorie   = $_POST['categorie']        ?? '';

        if (empty($titre) || empty($description) || $prix === '' || empty($categorie)) {
            return ['error' => 'Tous les champs obligatoires doivent être remplis.'];
        }
        if (!is_numeric($prix) || (float)$prix < 0) {
            return ['error' => 'Le prix doit être un nombre positif.'];
        }

        $photo = $this->uploadPhoto();
        if (isset($photo['error'])) {
            return $photo;
        }

        $this->model->update($id, $titre, $description, (float)$prix, $categorie, $photo);
        return ['success' => 'Annonce modifiée avec succès.'];
    }

    /** Supprime une annonce */
    public function supprimer(int $id): array
    {
        if (empty($_SESSION['user_id'])) {
            return ['error' => 'Vous devez être connecté.'];
        }

        $annonce = $this->model->findById($id);
        if (!$annonce || $annonce['user_id'] !== (int) $_SESSION['user_id']) {
            return ['error' => 'Annonce introuvable ou accès refusé.'];
        }

        // Supprimer la photo du serveur si elle existe
        if (!empty($annonce['photo'])) {
            $chemin = __DIR__ . '/../uploads/' . $annonce['photo'];
            if (file_exists($chemin)) {
                unlink($chemin);
            }
        }

        $this->model->delete($id);
        return ['success' => 'Annonce supprimée.'];
    }

    /** Gère l'upload de photo */
    private function uploadPhoto(): string|null|array
    {
        if (empty($_FILES['photo']['name'])) {
            return null;
        }

        $file      = $_FILES['photo'];
        $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $autorise  = ['jpg', 'jpeg', 'png', 'webp'];

        if (!in_array($extension, $autorise)) {
            return ['error' => 'Format de photo non autorisé (jpg, jpeg, png, webp).'];
        }
        if ($file['size'] > 5 * 1024 * 1024) {
            return ['error' => 'La photo ne doit pas dépasser 5 Mo.'];
        }

        $nomFichier = uniqid('annonce_') . '.' . $extension;
        move_uploaded_file($file['tmp_name'], __DIR__ . '/../uploads/' . $nomFichier);

        return $nomFichier;
    }
}