<?php
require_once __DIR__ . '/../models/message.model.php';
require_once __DIR__ . '/../models/annonce.model.php';

class MessageController
{
    private MessageModel $model;
    private AnnonceModel $annonceModel;

    public function __construct()
    {
        $this->model        = new MessageModel();
        $this->annonceModel = new AnnonceModel();
    }

    /** Envoie un message */
   public function envoyer(int $annonceId): void
{
    if (empty($_SESSION['user_id'])) {
        header('Location: index.php?page=login');
        exit;
    }

    $contenu = trim($_POST['contenu'] ?? '');
    if (empty($contenu)) {
        $_SESSION['flash'] = ['type' => 'error', 'message' => 'Le message ne peut pas être vide.'];
        header('Location: index.php?page=messages');
        exit;
    }

    $annonce = $this->annonceModel->findById($annonceId);
    if (!$annonce) {
        $_SESSION['flash'] = ['type' => 'error', 'message' => 'Annonce introuvable.'];
        header('Location: index.php?page=messages');
        exit;
    }

    // Récupère le destinataire depuis le formulaire
    $destinataireId = (int) ($_POST['destinataire_id'] ?? 0);
    if ($destinataireId === 0) {
        $_SESSION['flash'] = ['type' => 'error', 'message' => 'Destinataire introuvable.'];
        header('Location: index.php?page=messages');
        exit;
    }

    // On ne peut pas s'envoyer un message à soi-même
    if ($destinataireId === (int) $_SESSION['user_id']) {
        $_SESSION['flash'] = ['type' => 'error', 'message' => 'Vous ne pouvez pas vous envoyer un message.'];
        header('Location: index.php?page=messages');
        exit;
    }

    $this->model->create($annonceId, (int) $_SESSION['user_id'], $destinataireId, $contenu);
    $_SESSION['flash'] = ['type' => 'success', 'message' => 'Message envoyé avec succès.'];
    header('Location: index.php?page=messages&annonce_id=' . $annonceId . '&avec=' . $destinataireId);
    exit;
}

    /** Récupère toutes les conversations */
    public function getConversations(): array
    {
        if (empty($_SESSION['user_id'])) {
            return [];
        }
        return $this->model->findConversations((int) $_SESSION['user_id']);
    }

    /** Récupère les messages d'une conversation */
    public function getMessages(int $annonceId, int $avecUserId): array
    {
        if (empty($_SESSION['user_id'])) {
            return [];
        }
        $messages = $this->model->findByConversation($annonceId, (int) $_SESSION['user_id'], $avecUserId);
        $this->model->markAsRead($annonceId, (int) $_SESSION['user_id']);
        return $messages;
    }

    /** Compte les messages non lus */
    public function countUnread(): int
    {
        if (empty($_SESSION['user_id'])) {
            return 0;
        }
        return $this->model->countUnread((int) $_SESSION['user_id']);
    }
}