<?php
require_once __DIR__ . '/../models/user.model.php';

class UserController
{
    private UserModel $model;

    public function __construct()
    {
        $this->model = new UserModel();
    }

    // ========================
    // INSCRIPTION
    // ========================
    public function inscription(): string
    {
        $email    = trim($_POST['email']   ?? '');
        $password = $_POST['password']     ?? '';
        $confirm  = $_POST['confirm']      ?? '';

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return 'Email invalide.';
        }
        if (strlen($password) < 10) {
            return 'Le mot de passe doit contenir au moins 10 caractères.';
        }
        if ($password !== $confirm) {
            return 'Les mots de passe ne correspondent pas.';
        }
        if ($this->model->emailExists($email)) {
            return 'Cet email est déjà utilisé.';
        }

        $this->model->create($email, password_hash($password, PASSWORD_DEFAULT));
        $_SESSION['flash'] = ['type' => 'success', 'message' => 'Compte créé avec succès ! Vous pouvez maintenant vous connecter.'];
header('Location: index.php?page=login');
exit;
    }

    // ========================
    // CONNEXION
    // ========================
    public function connexion(): void
    {
        $email    = trim($_POST['email']   ?? '');
        $password = $_POST['password']     ?? '';

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $_SESSION['flash'] = ['type' => 'error', 'message' => 'Email invalide.'];
            return;
        }

        $user = $this->model->findByEmail($email);

        if (!$user || !password_verify($password, $user['password'])) {
            $_SESSION['flash'] = ['type' => 'error', 'message' => 'Email ou mot de passe incorrect.'];
            return;
        }

        $_SESSION['user_id'] = $user['id'];
        $_SESSION['email']   = $user['email'];

        header('Location: index.php');
        exit;
    }

    // ========================
    // DÉCONNEXION
    // ========================
    public function deconnexion(): void
    {
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(
                session_name(), '',
                time() - 42000,
                $params['path'], $params['domain'],
                $params['secure'], $params['httponly']
            );
        }
        session_destroy();
        header('Location: index.php?page=login');
        exit;
    }

    // ========================
    // PROFIL
    // ========================
    public function getProfil(int $id): array|false
    {
        return $this->model->findById($id);
    }

    public function modifierEmail(): string
    {
        $nouvelEmail = trim($_POST['email'] ?? '');
        $password    = $_POST['password']   ?? '';

        if (!filter_var($nouvelEmail, FILTER_VALIDATE_EMAIL)) {
            return 'Email invalide.';
        }

        $user = $this->model->findById((int) $_SESSION['user_id']);
        if (!$user || !password_verify($password, $user['password'])) {
            return 'Mot de passe incorrect.';
        }

        if ($this->model->emailExists($nouvelEmail)) {
            return 'Cet email est déjà utilisé.';
        }

        $this->model->updateEmail((int) $_SESSION['user_id'], $nouvelEmail);
        $_SESSION['email'] = $nouvelEmail;
        return 'Email mis à jour avec succès.';
    }

    public function modifierMotDePasse(): string
    {
        $ancien  = $_POST['ancien_password']  ?? '';
        $nouveau = $_POST['nouveau_password'] ?? '';
        $confirm = $_POST['confirm_password'] ?? '';

        if (strlen($nouveau) < 10) {
            return 'Le nouveau mot de passe doit contenir au moins 10 caractères.';
        }
        if ($nouveau !== $confirm) {
            return 'Les mots de passe ne correspondent pas.';
        }

        $user = $this->model->findById((int) $_SESSION['user_id']);
        if (!$user || !password_verify($ancien, $user['password'])) {
            return 'Ancien mot de passe incorrect.';
        }

        $this->model->updatePassword((int) $_SESSION['user_id'], password_hash($nouveau, PASSWORD_DEFAULT));
        return 'Mot de passe modifié avec succès.';
    }

    public function supprimerCompte(): void
    {
        $password = $_POST['password_confirm'] ?? '';

        $user = $this->model->findById((int) $_SESSION['user_id']);
        if (!$user || !password_verify($password, $user['password'])) {
            $_SESSION['flash'] = ['type' => 'error', 'message' => 'Mot de passe incorrect. Suppression annulée.'];
            header('Location: index.php?page=profil');
            exit;
        }

        $this->model->delete((int) $_SESSION['user_id']);

        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(
                session_name(), '',
                time() - 42000,
                $params['path'], $params['domain'],
                $params['secure'], $params['httponly']
            );
        }
        session_destroy();
        header('Location: index.php');
        exit;
    }

    public function getMesAnnonces(int $id): array
    {
        return $this->model->getAnnonces($id);
    }
}