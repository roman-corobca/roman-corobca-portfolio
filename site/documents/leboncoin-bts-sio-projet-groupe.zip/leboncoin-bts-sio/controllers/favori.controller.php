<?php
require_once __DIR__ . '/../models/favori.model.php';

class FavoriController
{
    private FavoriModel $model;

    public function __construct()
    {
        $this->model = new FavoriModel();
    }

    /** Ajoute ou retire un favori */
    public function toggle(int $annonceId): void
    {
        if (empty($_SESSION['user_id'])) {
            header('Location: index.php?page=login');
            exit;
        }

        $userId = (int) $_SESSION['user_id'];

        if ($this->model->isFavori($userId, $annonceId)) {
            $this->model->remove($userId, $annonceId);
        } else {
            $this->model->add($userId, $annonceId);
        }
    }

    /** Récupère les favoris de l'utilisateur connecté */
    public function getFavoris(): array
    {
        if (empty($_SESSION['user_id'])) {
            return [];
        }
        return $this->model->findByUser((int) $_SESSION['user_id']);
    }

    /** Vérifie si une annonce est en favori */
    public function isFavori(int $annonceId): bool
    {
        if (empty($_SESSION['user_id'])) {
            return false;
        }
        return $this->model->isFavori((int) $_SESSION['user_id'], $annonceId);
    }
}