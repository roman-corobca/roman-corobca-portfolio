<?php
require_once __DIR__ . '/../config/database.php';

class UserModel
{
    private PDO $pdo;

    public function __construct()
    {
        $this->pdo = getDBConnection();
    }

    public function findByEmail(string $email): array|false
    {
        $stmt = $this->pdo->prepare('SELECT * FROM users WHERE email = ?');
        $stmt->execute([$email]);
        return $stmt->fetch();
    }

    public function findById(int $id): array|false
    {
        $stmt = $this->pdo->prepare('SELECT * FROM users WHERE id = ?');
        $stmt->execute([$id]);
        return $stmt->fetch();
    }

    public function emailExists(string $email): bool
    {
        $stmt = $this->pdo->prepare('SELECT id FROM users WHERE email = ?');
        $stmt->execute([$email]);
        return $stmt->rowCount() > 0;
    }

    public function create(string $email, string $hashedPassword): bool
    {
        $stmt = $this->pdo->prepare('INSERT INTO users (email, password) VALUES (?, ?)');
        return $stmt->execute([$email, $hashedPassword]);
    }

    public function updateEmail(int $id, string $email): bool
    {
        $stmt = $this->pdo->prepare('UPDATE users SET email = ? WHERE id = ?');
        return $stmt->execute([$email, $id]);
    }

    public function updatePassword(int $id, string $hashedPassword): bool
    {
        $stmt = $this->pdo->prepare('UPDATE users SET password = ? WHERE id = ?');
        return $stmt->execute([$hashedPassword, $id]);
    }

    public function delete(int $id): bool
    {
        $stmt = $this->pdo->prepare('DELETE FROM users WHERE id = ?');
        return $stmt->execute([$id]);
    }

    public function getAnnonces(int $id): array
    {
        $stmt = $this->pdo->prepare('SELECT * FROM annonces WHERE user_id = ? ORDER BY created_at DESC');
        $stmt->execute([$id]);
        return $stmt->fetchAll();
    }
}