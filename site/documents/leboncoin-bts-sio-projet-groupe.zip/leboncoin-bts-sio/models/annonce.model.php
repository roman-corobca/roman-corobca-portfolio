<?php
require_once __DIR__ . '/../config/database.php';

class AnnonceModel
{
    private PDO $pdo;

    public function __construct()
    {
        $this->pdo = getDBConnection();
    }

    /** Toutes les annonces avec filtres et tri optionnels */
    public function findAll(array $filtres = []): array
    {
        $sql    = 'SELECT a.*, u.email as vendeur_email FROM annonces a JOIN users u ON a.user_id = u.id WHERE 1=1';
        $params = [];

        if (!empty($filtres['categorie'])) {
            $sql .= ' AND a.categorie = ?';
            $params[] = $filtres['categorie'];
        }
        if (!empty($filtres['prix_min'])) {
            $sql .= ' AND a.prix >= ?';
            $params[] = (float) $filtres['prix_min'];
        }
        if (!empty($filtres['prix_max'])) {
            $sql .= ' AND a.prix <= ?';
            $params[] = (float) $filtres['prix_max'];
        }
        if (!empty($filtres['recherche'])) {
            $sql .= ' AND (a.titre LIKE ? OR a.description LIKE ?)';
            $params[] = '%' . $filtres['recherche'] . '%';
            $params[] = '%' . $filtres['recherche'] . '%';
        }

        // Tri
        $trisAutorises = ['created_at_desc', 'created_at_asc', 'prix_asc', 'prix_desc'];
        $tri = in_array($filtres['tri'] ?? '', $trisAutorises) ? $filtres['tri'] : 'created_at_desc';

        $orderBy = match($tri) {
            'created_at_asc' => 'a.created_at ASC',
            'prix_asc'       => 'a.prix ASC',
            'prix_desc'      => 'a.prix DESC',
            default          => 'a.created_at DESC',
        };

        $sql .= ' ORDER BY ' . $orderBy;

        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    /** Les annonces les plus consultées */
    public function findPopulaires(int $limite = 5): array
    {
        $stmt = $this->pdo->prepare(
            'SELECT a.*, u.email as vendeur_email
             FROM annonces a
             JOIN users u ON a.user_id = u.id
             WHERE a.nb_vues > 0
             ORDER BY a.nb_vues DESC
             LIMIT ?'
        );
        $stmt->execute([$limite]);
        return $stmt->fetchAll();
    }

    /** Une annonce par ID */
    public function findById(int $id): array|false
    {
        $stmt = $this->pdo->prepare('SELECT a.*, u.email as vendeur_email FROM annonces a JOIN users u ON a.user_id = u.id WHERE a.id = ?');
        $stmt->execute([$id]);
        return $stmt->fetch();
    }

    /** Annonces d'un utilisateur */
    public function findByUser(int $userId): array
    {
        $stmt = $this->pdo->prepare('SELECT * FROM annonces WHERE user_id = ? ORDER BY created_at DESC');
        $stmt->execute([$userId]);
        return $stmt->fetchAll();
    }

    /** Crée une annonce */
    public function create(int $userId, string $titre, string $description, float $prix, string $categorie, ?string $photo): bool
    {
        $stmt = $this->pdo->prepare('INSERT INTO annonces (user_id, titre, description, prix, categorie, photo) VALUES (?, ?, ?, ?, ?, ?)');
        return $stmt->execute([$userId, $titre, $description, $prix, $categorie, $photo]);
    }

    /** Dernière annonce insérée */
    public function lastInsertId(): int
    {
        return (int) $this->pdo->lastInsertId();
    }

    /** Modifie une annonce */
    public function update(int $id, string $titre, string $description, float $prix, string $categorie, ?string $photo): bool
    {
        if ($photo) {
            $stmt = $this->pdo->prepare('UPDATE annonces SET titre=?, description=?, prix=?, categorie=?, photo=? WHERE id=?');
            return $stmt->execute([$titre, $description, $prix, $categorie, $photo, $id]);
        }
        $stmt = $this->pdo->prepare('UPDATE annonces SET titre=?, description=?, prix=?, categorie=? WHERE id=?');
        return $stmt->execute([$titre, $description, $prix, $categorie, $id]);
    }

    /** Supprime une annonce */
    public function delete(int $id): bool
    {
        $stmt = $this->pdo->prepare('DELETE FROM annonces WHERE id = ?');
        return $stmt->execute([$id]);
    }

    /** Incrémente le compteur de vues */
    public function incrementVues(int $id): void
    {
        $this->pdo->prepare('UPDATE annonces SET nb_vues = nb_vues + 1 WHERE id = ?')->execute([$id]);
    }
}