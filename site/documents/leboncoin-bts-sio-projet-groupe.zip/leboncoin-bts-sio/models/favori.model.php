<?php
require_once __DIR__ . '/../config/database.php';

class FavoriModel
{
    private PDO $pdo;

    public function __construct()
    {
        $this->pdo = getDBConnection();
    }

    /** Récupère tous les favoris d'un utilisateur */
    public function findByUser(int $userId): array
    {
        $stmt = $this->pdo->prepare('
            SELECT a.*, u.email as vendeur_email
            FROM favoris f
            JOIN annonces a ON f.annonce_id = a.id
            JOIN users u ON a.user_id = u.id
            WHERE f.user_id = ?
            ORDER BY f.created_at DESC
        ');
        $stmt->execute([$userId]);
        return $stmt->fetchAll();
    }

    /** Vérifie si une annonce est en favori */
    public function isFavori(int $userId, int $annonceId): bool
    {
        $stmt = $this->pdo->prepare('SELECT id FROM favoris WHERE user_id = ? AND annonce_id = ?');
        $stmt->execute([$userId, $annonceId]);
        return $stmt->rowCount() > 0;
    }

    /** Ajoute un favori */
    public function add(int $userId, int $annonceId): bool
    {
        $stmt = $this->pdo->prepare('INSERT INTO favoris (user_id, annonce_id) VALUES (?, ?)');
        return $stmt->execute([$userId, $annonceId]);
    }

    /** Supprime un favori */
    public function remove(int $userId, int $annonceId): bool
    {
        $stmt = $this->pdo->prepare('DELETE FROM favoris WHERE user_id = ? AND annonce_id = ?');
        return $stmt->execute([$userId, $annonceId]);
    }
}