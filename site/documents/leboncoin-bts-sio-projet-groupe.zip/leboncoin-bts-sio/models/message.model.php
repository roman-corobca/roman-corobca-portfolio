<?php
require_once __DIR__ . '/../config/database.php';

class MessageModel
{
    private PDO $pdo;

    public function __construct()
    {
        $this->pdo = getDBConnection();
    }

    /** Récupère tous les échanges d'un utilisateur groupés par annonce */
    public function findConversations(int $userId): array
    {
        $stmt = $this->pdo->prepare('
            SELECT
                m.*,
                a.titre as annonce_titre,
                a.photo as annonce_photo,
                a.id as annonce_id,
                u_exp.email as expediteur_email,
                u_dest.email as destinataire_email
            FROM messages m
            JOIN annonces a ON m.annonce_id = a.id
            JOIN users u_exp ON m.expediteur_id = u_exp.id
            JOIN users u_dest ON m.destinataire_id = u_dest.id
            WHERE m.expediteur_id = ? OR m.destinataire_id = ?
            ORDER BY m.created_at DESC
        ');
        $stmt->execute([$userId, $userId]);
        return $stmt->fetchAll();
    }

    /** Récupère les messages d'une conversation (annonce + 2 utilisateurs) */
    public function findByConversation(int $annonceId, int $user1, int $user2): array
    {
        $stmt = $this->pdo->prepare('
            SELECT m.*, u.email as expediteur_email
            FROM messages m
            JOIN users u ON m.expediteur_id = u.id
            WHERE m.annonce_id = ?
            AND (
                (m.expediteur_id = ? AND m.destinataire_id = ?)
                OR
                (m.expediteur_id = ? AND m.destinataire_id = ?)
            )
            ORDER BY m.created_at ASC
        ');
        $stmt->execute([$annonceId, $user1, $user2, $user2, $user1]);
        return $stmt->fetchAll();
    }

    /** Envoie un message */
    public function create(int $annonceId, int $expediteurId, int $destinataireId, string $contenu): bool
    {
        $stmt = $this->pdo->prepare('
            INSERT INTO messages (annonce_id, expediteur_id, destinataire_id, contenu)
            VALUES (?, ?, ?, ?)
        ');
        return $stmt->execute([$annonceId, $expediteurId, $destinataireId, $contenu]);
    }

    /** Marque les messages comme lus */
    public function markAsRead(int $annonceId, int $userId): void
    {
        $this->pdo->prepare('
            UPDATE messages SET lu = 1
            WHERE annonce_id = ? AND destinataire_id = ?
        ')->execute([$annonceId, $userId]);
    }

    /** Compte les messages non lus */
    public function countUnread(int $userId): int
    {
        $stmt = $this->pdo->prepare('SELECT COUNT(*) FROM messages WHERE destinataire_id = ? AND lu = 0');
        $stmt->execute([$userId]);
        return (int) $stmt->fetchColumn();
    }
}